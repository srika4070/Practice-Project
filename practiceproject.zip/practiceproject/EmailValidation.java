package practiceproject;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailValidation {


		public static void main(String[] args) {
	        // Array of strings

	        ArrayList<String> emailID = new ArrayList<String>();
	
			emailID.add("user@gmail.com");
			emailID.add("student@yahoo.com");
			emailID.add("information@hotmail.com");
			emailID.add("program@outlook.com");
			emailID.add("class@gmail.com");
			emailID.add("testing@hotmail.com");
		

	        // Get input from user
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a string to search: ");
	        String searchString = scanner.nextLine();

	        // Search the array for the entered string
	        boolean found = false;
	   
			for (String str : emailID) {
	            if (str.equalsIgnoreCase(searchString)) {
	                found = true;
	                break;
	            }
	        }

	        // Display search result
	        if (found) {
	            System.out.println("String '" + searchString + "' found in the array.");
	        } else {
	            System.out.println("String '" + searchString + "' not found in the array.");
	        }

	        // Validate email format
	        System.out.print("Enter an email to validate: ");
	        String email = scanner.nextLine();
	        if (isValidEmail(email)) {
	            System.out.println("Valid email address: " + email);
	        } else {
	            System.out.println("Invalid email address: " + email);
	        }

	        scanner.close();
	    }

	    // Method to validate email address using regex
	    public static boolean isValidEmail(String email) {
	        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	        Pattern pattern = Pattern.compile(emailRegex);
	        Matcher matcher = pattern.matcher(email);
	        return matcher.matches();
	    }
	}

