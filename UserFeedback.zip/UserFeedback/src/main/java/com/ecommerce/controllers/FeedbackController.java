package com.ecommerce.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.dao.FeedbackDAO;
import com.ecommerce.entity.Feedback;

@RestController
public class FeedbackController {
	@Autowired
	FeedbackDAO dao;
	@PostMapping("/submitFeedback")
	public String submitFeedback(Feedback fb)
	{
		System.out.println("hello World!");
		dao.save(fb);
		return "<h2> Feedback submitted Successfully </h2>";
		
		
		
	}

}