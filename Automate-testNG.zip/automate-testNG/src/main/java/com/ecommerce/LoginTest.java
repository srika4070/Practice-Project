package com.ecommerce;

import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ecommerce.BaseTest;

public class LoginTest extends BaseTest {
	By username = By.id("user-name");
	By Password = By.id("password");
	By loginbutton = By.id("login-button");
	By HomePageHeader = By.xpath("//div[text()='Swag Labs']");

	@Test
	public void testlogin() throws IOException, InterruptedException {
		driver.get("https://www.saucedemo.com/");
		capture();
		driver.findElement(username).sendKeys("standard_user");
		Thread.sleep(10000);
		driver.findElement(Password).sendKeys("secret_sauce");
		Thread.sleep(10000);
		driver.findElement(loginbutton).click();
		Thread.sleep(10000);
		Boolean status = driver.findElement(HomePageHeader).isDisplayed();
		Assert.assertTrue(status);

	}

}