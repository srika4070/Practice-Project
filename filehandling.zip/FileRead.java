package practiceproject;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
public class FileRead {
	
		public static void main(String[] args){
		String Filepath = "C:\\Users\\sri2k\\.git\\Readme.txt";
		
		try {
			List<String> lines = Files.readAllLines(Paths.get(Filepath));

			// Print only those lines that has hello in it
			for (String line : lines) {
				if (line.contains("hello"))
					System.out.println(line);
			}
		} catch (FileNotFoundException e) {
				e.printStackTrace();
		} catch (IOException e) {
				e.printStackTrace();
			
			}
		}
}

