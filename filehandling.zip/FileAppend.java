package practiceproject;
import java.io.*;
public class FileAppend {

public static void main(String[] args) {
	String FilePath = "C:\\Users\\sri2k\\.git\\Readme.txt";

	FileWriter writen = null;
	try {
		writen = new FileWriter(FilePath,true); // true is for append mode

		writen.write("\nwhere are you?");
		
		System.out.println("Done");

	} catch (IOException e) {
		e.printStackTrace();
	} finally {
		try {
			writen.close();
			System.out.println("Successfully appended to the file.");
		} catch (IOException e) {
			 System.out.println("An error occurred while appending to the file.");
			e.printStackTrace();
		}
	}

}
}