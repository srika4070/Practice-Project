package practiceproject;

import java.io.*;;

public class FileWrite {
	
public static void main(String[] args) {
	String FilePath = "C:\\Users\\sri2k\\.git\\Readme.txt";

	FileWriter writer = null;
	try {
		writer = new FileWriter(FilePath, false);// false is for overwrite mode

		writer.write("hi! hello! How are you?");
		
		System.out.println("Done");

	} catch (IOException e) {
		e.printStackTrace();
	} finally {
		try {
			writer.close();
			System.out.println("Successfully write to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred while writing to the file.");
			e.printStackTrace();
		}
	}

}
}
