package com.ecommerce;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class FlipkartLazyLoadingTest {
 WebDriver driver;


@BeforeTest
 public void setUp() {
     WebDriverManager.firefoxdriver().setup();
     driver = new FirefoxDriver();
     driver.manage().window().maximize();
    
 }

@Test
 public void testLazyLoading() throws InterruptedException {
	 
	 //Navigate to FlipKart Home Page
	 driver.get("https://www.flipkart.com/");
    
	// Measure page load time - Start
	 long startTime = System.currentTimeMillis();
	 System.out.println("Start Time for page load: " + startTime);

	 

	 // Measure page load time - End
	 long finish = System.currentTimeMillis();
	 System.out.println("Finish Time for page load: " + finish);

	 long totalTime = finish - startTime;
	 System.out.println("Total Time for page load: " + totalTime + " milliseconds");

     

     // Search for "iPhone 13" under the "Mobile" category
     WebElement searchBox = driver.findElement(By.name("q"));
     searchBox.sendKeys("iPhone 13");
     driver.findElement(By.cssSelector("button[type='submit']")).click();

  
     // Check images are loaded and visible till the screen height
     
     WebElement firstProductImage = driver.findElement(By.partialLinkText("Apple iPhone 13 (Starlight, 128 GB)"));
     if (firstProductImage.isDisplayed()) {
     System.out.println("First product image is visible.");
     } else {
     System.out.println("First product image is not visible.");
     }
    


     // Check if the page has a scroll feature
     boolean isScrollable = (boolean) ((JavascriptExecutor) driver).executeScript(
             "return document.documentElement.scrollHeight > window.innerHeight;");
     if (isScrollable) {
         System.out.println("The page has a scroll feature");
     } else {
         System.out.println("The page does not have a scroll feature");
     }
     

	//Check the frequency at which the content will be refreshed while scrolling
	long refreshStartTime = System.currentTimeMillis();
	// Your logic to identify the frequency of content refresh
	long refreshEndTime = System.currentTimeMillis();
	long refreshTime = refreshEndTime - refreshStartTime;
    
    System.out.println  ("Content Refresh Frequency: " + refreshTime + " milliseconds");
}
    
	@Test
     public void testLazyLoading1() {
         // Check images are loaded and visible till the screen height
         WebElement firstProductImage = driver.findElement(By.partialLinkText("Apple iPhone 13 (Starlight, 128 GB)"));
         if (firstProductImage.isDisplayed()) {
             System.out.println("First product image is visible.");
         } else {
             System.out.println("First product image is not visible.");
         }

         

         // Verify that the image is downloaded just before the user scrolls to its position and gets displayed in time
         WebElement lazyLoadedImage = driver.findElement(By.partialLinkText("Apple iPhone 13 (Midnight, 128 GB)"));
         scrollIntoView(lazyLoadedImage);
       
        
         System.out.println("Lazy-loaded image is visible after scrolling.");

         // Verify it navigates to the bottom of the page
         WebElement we = driver.findElement(By.partialLinkText("Apple iPhone 13 (Midnight, 128 GB)"));
         scrollIntoView(we);
         we.click();
         
     }

     // Function to scroll an element into view using JavaScript
     private void scrollIntoView(WebElement element) {
         ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
     
     }
     


@AfterTest
public void tearDown() {
    // Close the browser
	if(driver!=null) {
    driver.quit();
}
}
}