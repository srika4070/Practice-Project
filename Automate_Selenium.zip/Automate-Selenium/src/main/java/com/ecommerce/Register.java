package com.ecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {

	public static void main(String[] args) {
		
		WebDriver d = new ChromeDriver();
    	d.manage().window().maximize();
    	d.get("http://localhost/Login%20Page/login.php");
    	d.findElement(By.id("regname")).sendKeys("student");
    	d.findElement(By.id("password")).sendKeys("pass123");
    	d.findElement(By.id("email")).sendKeys("class@gmail.com");
    	d.findElement(By.id("phno")).sendKeys("7832859833");
    	d.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/h2[2]/form/button")).click();

	}

}