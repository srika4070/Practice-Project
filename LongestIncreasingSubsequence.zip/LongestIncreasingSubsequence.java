package practiceproject;

import java.util.*;
public class LongestIncreasingSubsequence {


    public static int longestIncreasingSubsequence(int[] nums) {
        if (nums == null || nums.length == 0) {
            return 0;
        }

        int n = nums.length;
        int[] Lis = new int[n];
        Arrays.fill(Lis, 1);

        int maxLength = 1;

        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (nums[i] > nums[j]) {
                    Lis[i] = Math.max(Lis[i], Lis[j] + 1);
                }
            }
            maxLength = Math.max(maxLength, Lis[i]);
        }

        return maxLength;
    }

    public static void main(String[] args) {
        int[] sequence = {9, 11, 7, 22, 18, 30, 43, 70};
        int length = longestIncreasingSubsequence(sequence);
        System.out.println("Length of Longest Increasing Subsequence: " + length);
    }
}