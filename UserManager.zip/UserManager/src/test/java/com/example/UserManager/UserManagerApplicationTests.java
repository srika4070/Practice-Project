package com.example.UserManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
